package e2p1_gabrielosorto;

import static java.lang.Integer.parseInt;
import javax.swing.JOptionPane;

public class E2P1_GabrielOsorto {

    static String base;
    static int num;

    public static void main(String[] args) {
        Menu M = new Menu();
        M.setVisible(true);

    }

    public static void boton1() {
        int b;
        b = Integer.parseInt(JOptionPane.showInputDialog("Numeros \n 1. Agregar numero.,\n 2. Eliminar numero.,\n 3. Volver al menu principal.", ""));
        int c;
        c = (b);
        switch (c) {
            case 1 -> {
                base = JOptionPane.showInputDialog(null, "Ingrese la base:");
                int bc;
                bc = parseInt(base);
                while ((bc > 35) || (bc < 2)) {
                    base =JOptionPane.showInputDialog(null, "Ingrese una base mayor que 2 y menor que 35:");
                    bc = parseInt(base);
                }//fin validacion base
                num = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el numero:"));
                int nm;
                nm = (num);
                while (nm <= 1) {
                    num = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero positivo mayor a 1:"));
                    nm = (num);
                    decToBase(bc);
                }//fin validacion num
                break;
            }//Fin case 1
            case 2 -> {
                break;
            }//fin case 2
            case 3 -> {
                break;
            }//fin case 3
        }
    }

    public static void boton2() {
        int b;
        b = Integer.parseInt(JOptionPane.showInputDialog("Operaciones \n 1. Sumar numeros.,\n 2. Restar numeros.,\n 3. Multiplicar numeros.\n 4. Menu Principal.", ""));
        int c;
        c = (b);
        boolean seguir = true;
        switch (c) {
            case 1 -> {
                break;
            }//Fin case 1
            case 2 -> {
                break;
            }//fin case 2
            case 3 -> {
                break;
            }//fin case 3
            case 4 -> {
                seguir = false;
                break;
            }//fin case 4
        }
    }

    private static void decToBase(int bc) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public int Binario(int bc, int nm){
        while (nm<bc){
            int reci=num%bc;
        }
    
return 0;}
    
}
