package e2p1_gabrielosorto;

import static java.lang.Integer.parseInt;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.*;

public class E2P1_GabrielOsorto {

    static String base;
    static int num;
    Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        Menu M = new Menu();
        M.setVisible(true);
        ArrayList<Numero> nums = new ArrayList<>();
    }

    public static void boton1() {
        ArrayList<Numero> nums = new ArrayList<>();
        boolean seguir=true;
        int b;
        b = Integer.parseInt(JOptionPane.showInputDialog("Numeros \n 1. Agregar numero.,\n 2. Eliminar numero.,\n 3. Volver al menu principal.", ""));
        int c;
        c = (b);
        switch (c) {
            case 1 -> {
                base = JOptionPane.showInputDialog(null, "Ingrese la base:");
                int bc;
                bc = parseInt(base);
                while ((bc > 35) || (bc < 2)) {
                    base = JOptionPane.showInputDialog(null, "Ingrese una base mayor que 2 y menor que 35:");
                    bc = parseInt(base);
                }//fin validacion base
                num = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el valor decimal del numero:"));
                int nm;
                nm = (num);
                while (nm <= 1) {
                    num = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese un numero positivo mayor a 1:"));
                    nm = (num);
                }//fin validacion num
                Numero num = new Numero(bc, nm);
                nums.add(num);
                JOptionPane.showMessageDialog(null, "¡¡Valor aregado exitosamente!!");
                break;
            }//Fin case 1

            case 2 -> {
                int indie = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la base del número a elimina"));
                if (indie>= 0 && indie < nums.size()) {
                    nums.remove(indie);
                    JOptionPane.showMessageDialog(null, "Numeo eliminado exitosamente!!");
                } else {
                    JOptionPane.showMessageDialog(null, "Opcion invalida:(");
                }
            }//fin case 2

            case 3 -> {
                JOptionPane.showMessageDialog(null, "SALIENDOOOOOOOOOO AL MENU PRINCIPAAAAAAL");
                seguir=false;
                break;
            }//fin case 3
        }
    }

    public static void boton2() {
                ArrayList<Numero> nums = new ArrayList<>();
        int b;
        b = Integer.parseInt(JOptionPane.showInputDialog("Operaciones \n 1. Sumar numeros.,\n 2. Restar numeros.,\n 3. Multiplicar numeros.\n 4. Menu Principal.", ""));
        int c;
        c = (b);
        boolean seguir = true;
        switch (c) {
            case 1 -> {
                JOptionPane.showMessageDialog(null,"Seleccione dos números para la operación:");
                for (int i = 0; i < nums.size(); i++) {
                JOptionPane.showMessageDialog(null, i + ". " + nums.get(i).getNumero());
                }//fin for
                int b1= Integer.parseInt( JOptionPane.showInputDialog("Ingrese el primer digito:",null));
                int B2=(b1);
                int b2= Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo digito:",null));
                
                break;
            }//Fin case 1
            case 2 -> {
                break;
            }//fin case 2
            case 3 -> {
                break;
            }//fin case 3
            case 4 -> {
                seguir = false;
                break;
            }//fin case 4
        }
    }

    private static void decToBase(int bc) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private char nac(int nm) {
        if (nm < 10) {
            return (char) (nm + '0');
        } else {
            return (char) (nm - 10 + 'A');
        }
    }

    private int can(char c) {
        if (Character.isDigit(c)) {
            return c - '0';
        } else {
            return Character.toUpperCase(c) - 'A' + 10;
        }
    }

    public String Binario(int bc, int nm) {
        var stb = new StringBuffer();
        while (nm > 0) {
            int r = nm % bc;
            char c = nac(r);
            stb.insert(0, c);
            nm /= bc;
        }
        return stb.toString();
    }

    private int btd(String num2, int bc) {
        int vd = 0;
        for (int i = 0; i < num2.length(); i++) {
            char c = num2.charAt(i);
            int num = can(c);
            vd = vd * bc + num;
        }
        return vd;
    }

}
