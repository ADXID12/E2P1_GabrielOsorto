package e2p1_gabrielosorto;
import java.util.ArrayList;
public class Numero {
    int base;
    int num;
    public Numero(int bc, int nm){
        this.base=bc;
        this.num=decToBase(nm);
    }

    private int decToBase(int nm) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    String getNumero() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
